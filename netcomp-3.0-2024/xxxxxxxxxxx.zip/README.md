# xxxxxxxxxxx [500 pts]

**Category:** Forensic
**Solves:** 0

## Description
>> I set up my new monitor, except it was not physically attached..

`Author: Avilia`

#### Hint 

## Solution

## Flag

