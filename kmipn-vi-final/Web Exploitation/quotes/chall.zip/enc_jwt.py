import jwt
JWT_SECRET = 'REDACTED_SECRET_KEY'

JWT_ALG = 'HS256'

username='admin'
jwtData = {"user": username}
cookie = jwt.encode(jwtData, JWT_SECRET, algorithm=JWT_ALG)
print(cookie)
