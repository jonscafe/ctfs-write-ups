# Woilah Cik [894 pts]

**Category:** Reverse Engineering
**Solves:** 32

## Description
>Woilah, cik! Mas Faiz dikasih challenge sama Wak Amba buat nyari tahu passwordnya Wak Amba. Mas Faiz dikasih 2 file, satu file buat nge-generate password, satu file buat ngecek password. Tolong Mas Faiz ya rek!\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=1gBZlpxzw_-qB7u5klsp-jVqHnlIlojdM)\r\n\r\nAuthor: pwnwas

**Hint**
* -

## Solution

### Flag

