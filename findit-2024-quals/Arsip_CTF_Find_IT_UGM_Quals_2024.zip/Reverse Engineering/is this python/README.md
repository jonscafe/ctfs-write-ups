# is this python [712 pts]

**Category:** Reverse Engineering
**Solves:** 47

## Description
>Sekarang giliran Wak Amba yang dikasih challenge sama Mas Faiz. Wak Amba dikasih satu file sama Mas Faiz, tapi pas filenya dibuka Wak Amba bingung, soalnya isinya kayak bahasa Assembly, tapi masih readable. Sekarang coba tolong Wak Amba ya rek!\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=1QKruKZzemp2dmfhr9GGuo3v6Ny4lJyRX)\r\n\r\nAuthor: pwnwas

**Hint**
* -

## Solution

### Flag

