# neobim enjoyer [982 pts]

**Category:** MISC
**Solves:** 10

## Description
>Quandale Dingle ingin menghadiri acara EliteCoder Rizz Party, namun dia belum sigma. Salah satu syarat untuk menjadi sigma di kalangan Rizzler adalah dengan menggunakan NeoVim dan Arch Linux. Quandale sudah menggunakan Arch linux namun belum pernah menggunakan NeoVim. Para Rizzler yang sudah sigma mengetes Quandale Dingle dengan memberikan sebuah NeoVim plugin (github.com/dundorma/neobimenjoyer) yang didalamnya terdapat pesan tersembunyi. Bantulah Quandale Dingle untuk menginstall plugin dan menemukan pesan tersembunyi tersebut. (wrap the flag in FindITCTF{})\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=11lx54YACcsYUA7t9vQKuIGL34585J_EQ)\r\n\r\nAuthor: xxi0n

**Hint**
* -

## Solution

### Flag

