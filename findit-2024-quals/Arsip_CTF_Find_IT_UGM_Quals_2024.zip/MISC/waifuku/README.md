# waifuku [1000 pts]

**Category:** MISC
**Solves:** 2

## Description
>ancrit foto waifuku napa malah jadi video woyyyy \xf0\x9f\x98\xad\xf0\x9f\x98\xad\xf0\x9f\x98\xad\r\n\r\nNote: The waifu name should be without spaces and in all lowercase letters.\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=1xwiCcDgRP2FMaEMer-cgCJKxd_jG__gX)\r\n\r\nAuthor: hilmo

**Hint**
* This is my masterpiece, written with my friend. Yin and Yang are with us.\n* 1 adalah putih 0 adalah hitam. Mereka bergerak dari dekat tempat di mana kursor bisa hilang di kedua sisi menuju ke tempat hanya 1 ujung kursor yang terlihat. Mereka melakukannya secara berulang ulang. Hingga akhirnya mereka berada di tempat kursor tidak bisa hilang lagi.

## Solution

### Flag

