# screenshot [998 pts]

**Category:** OSINT
**Solves:** 0

## Description
>One day, Asep wanted to contact me via a popular social media platform in Indonesia. However, he found something intriguing and took a screenshot: he discovered many Suzuki cars in there. He asked me to find the name among them that has the date "2024-03-13 05:58"\r\nFLAG =  FindITCTF{NAME}\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=1KX4Fj1J8k1gUl2Zr-Wwbqm1yq_mSnZf_)\r\n\r\nAuthor: hilmo

**Hint**
* Sometimes you should "twist" your brain\n* website medsos populer di indonesia tapi perhatikan clue sebelumnya \xf0\x9f\x91\x8d\n* Mungkinkah Asep salah ketik di keyboard dia? \npantas saja perusahaan besar banyak beli domain untuk 1 produk saja. Jika saja aku tahu Asep ada dimana mungkin sudah bisa kutebak pertanyaan dia \xf0\x9f\x98\xad.\n* ga ada hubungan sama sekali dengan pribadi manapun\n* Mungkin saja abang elceef bisa membantu kita dengan tools dia :(\n> kalau masih ga ketemu berarti ini bukan takdir kita\n> last hint

## Solution

### Flag

