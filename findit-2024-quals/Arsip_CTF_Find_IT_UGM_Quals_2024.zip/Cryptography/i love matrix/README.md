# i love matrix [979 pts]

**Category:** Cryptography
**Solves:** 12

## Description
>Today, your linear algebra lecturer taught you about something that you forgot the name of. You only remember two sentences. The first one is "Which vectors stay parallel with the original vectors?" and the second one is "How many times the original vectors is longer or shorter than the thing mentioned in the first sentence?"\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=14bU2ooItrD1g80IoH35eoJbXJeduOLq_)\r\n\r\nAuthor: hilmo

**Hint**
* -

## Solution

### Flag

