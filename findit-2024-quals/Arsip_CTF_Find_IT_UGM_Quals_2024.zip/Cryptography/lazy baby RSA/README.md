# lazy baby RSA [942 pts]

**Category:** Cryptography
**Solves:** 20

## Description
>Hey you! Yeah, you. If you have found this poster, may fate has brought us together. This challenge is only for a person who is patient enough to write an exceptionally long code just for a simple RSA. Are you scared? Haha.\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=1XgwYkwzRTIHuB0QXk_3aNRu2o7FO-RZF)\r\n\r\nAuthor: hilmo

**Hint**
* -

## Solution

### Flag

