# Image Cropper [972 pts]

**Category:** Forensics
**Solves:** 16

## Description
>Alice found a python script that in its documentation promises to make it easy to crop images to a 1:1 ratio. However, Alice was scammed by that script, which actually removed the input image she inserted and transformed it into another file. Meanwhile, the image holds something important for her. Can you help Alice get that important thing back?\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=1v_89appFFaa96Yi4HeZppcn7tUYpWJya)\r\n\r\nAuthor: BROP

**Hint**
* -

## Solution

### Flag

