# File Kosong [588 pts]

**Category:** Forensics
**Solves:** 61

## Description
>Joe Biden mendapatkan sebuah file dari Vladimir Putin. Akan tetapi, setelah dibuka Joe Biden, filenya ternyata kosong. Bantulah Joe Biden untuk menemukan pesannya.\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=1LrJNaSv4Zcv57gHVf1cccqLCREuhugdB)\r\n\r\nAuthor: LevireG

**Hint**
* -

## Solution

### Flag

