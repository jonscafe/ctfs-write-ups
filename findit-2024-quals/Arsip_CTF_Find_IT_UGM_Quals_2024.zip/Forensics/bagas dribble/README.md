# bagas dribble [327 pts]

**Category:** Forensics
**Solves:** 79

## Description
>Janggar get a file from a mysterius person. The person want him to find the truth behind the file.\r\n\r\n[Download File](https://drive.google.com/uc?export=download&id=1HOe6Rg5wkGY2RTtfId_UwQkFUUscKt_T)\r\n\r\nAuthor: LevireG

**Hint**
* -

## Solution

### Flag

